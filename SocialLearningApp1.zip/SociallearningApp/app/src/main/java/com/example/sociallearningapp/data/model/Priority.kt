package com.example.sociallearningapp.data.model

enum class Priority {
    LOW,
    MEDIUM,
    HIGH
}