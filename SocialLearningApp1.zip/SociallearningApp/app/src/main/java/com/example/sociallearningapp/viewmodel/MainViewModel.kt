package com.example.sociallearningapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sociallearningapp.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Date

class MainViewModel : ViewModel() {

    // Quiz History State
    private val _quizHistory = MutableStateFlow<List<QuizHistory>>(emptyList())
    val quizHistory: StateFlow<List<QuizHistory>> = _quizHistory.asStateFlow()

    // Tasks State
    private val _tasks = MutableStateFlow<List<Task>>(emptyList())
    val tasks: StateFlow<List<Task>> = _tasks.asStateFlow()

    private val _tasksCompleted = MutableStateFlow(0)
    val tasksCompleted: StateFlow<Int> = _tasksCompleted.asStateFlow()

    // User creation date
    private val _createdAt = MutableStateFlow(Date())
    val createdAt: StateFlow<Date> = _createdAt.asStateFlow()

    // Loading states
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Load sample data
                loadSampleQuizHistory()
                loadSampleTasks()
            } catch (e: Exception) {
                // Handle error
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun loadSampleQuizHistory() {
        val sampleHistory = listOf(
            QuizHistory(
                id = 1,
                quizId = 1,
                quizName = "Math Basics",
                score = 8,
                maxScore = 10,
                completedAt = Date(System.currentTimeMillis() - 86400000) // Yesterday
            ),
            QuizHistory(
                id = 2,
                quizId = 2,
                quizName = "Science Quiz",
                score = 7,
                maxScore = 10,
                completedAt = Date(System.currentTimeMillis() - 172800000) // 2 days ago
            ),
            QuizHistory(
                id = 3,
                quizId = 3,
                quizName = "History Challenge",
                score = 9,
                maxScore = 10,
                completedAt = Date(System.currentTimeMillis() - 259200000) // 3 days ago
            )
        )
        _quizHistory.value = sampleHistory
    }

    private fun loadSampleTasks() {
        val sampleTasks = listOf(
            Task(
                id = 1,
                title = "Complete Math Assignment",
                description = "Finish chapter 5 exercises",
                priority = Priority.HIGH,
                isCompleted = true,
                createdAt = Date(System.currentTimeMillis() - 86400000)
            ),
            Task(
                id = 2,
                title = "Read Science Article",
                description = "Read about quantum physics",
                priority = Priority.MEDIUM,
                isCompleted = false,
                createdAt = Date(System.currentTimeMillis() - 172800000)
            ),
            Task(
                id = 3,
                title = "Practice Vocabulary",
                description = "Learn 20 new words",
                priority = Priority.LOW,
                isCompleted = true,
                createdAt = Date(System.currentTimeMillis() - 259200000)
            )
        )
        _tasks.value = sampleTasks
        _tasksCompleted.value = sampleTasks.count { it.isCompleted }
    }

    fun addQuizResult(quizName: String, score: Int, maxScore: Int) {
        viewModelScope.launch {
            val newHistory = QuizHistory(
                id = _quizHistory.value.size + 1L,
                quizId = _quizHistory.value.size + 1L,
                quizName = quizName,
                score = score,
                maxScore = maxScore,
                completedAt = Date()
            )
            _quizHistory.value = _quizHistory.value + newHistory
        }
    }

    fun toggleTaskComplete(task: Task) {
        viewModelScope.launch {
            val updatedTasks = _tasks.value.map {
                if (it.id == task.id) {
                    it.copy(isCompleted = !it.isCompleted)
                } else {
                    it
                }
            }
            _tasks.value = updatedTasks
            _tasksCompleted.value = updatedTasks.count { it.isCompleted }
        }
    }

    fun addTask(title: String, description: String, priority: Priority) {
        viewModelScope.launch {
            val newTask = Task(
                id = _tasks.value.size + 1L,
                title = title,
                description = description,
                priority = priority,
                isCompleted = false,
                createdAt = Date()
            )
            _tasks.value = _tasks.value + newTask
        }
    }
}